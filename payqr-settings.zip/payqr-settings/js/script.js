/**
 /* 
 * Модуль  payqrActionModule, подключается на странице настроек плагина.
 */

var payqrActionModule = (function() {
  
  return { 
    lang: [], // локаль плагина 
    init: function() {      
      // установка локали плагина 
      admin.ajaxRequest({
          mguniqueurl: "action/seLocalesToPlug",
          pluginName: 'payqr-settings'
        },
        function(response) {
          payqrActionModule.lang = response.data;
        }
      );

       // Сохраняет базовые настроки запись
      $('.admin-center').on('click', '.section-payqr .base-setting-save', function() {
        
        var obj = '{';
        
        $('.widget-table input, .widget-table select').each(function() {
          obj += '"' + $(this).attr('name') + '":"' + $(this).val() + '",';
        });
        
        obj += '}';
    
        //преобразуем полученные данные в JS объект для передачи на сервер
        var data =  eval("(" + obj + ")");
        data.html_content_before = $('textarea[name=html_content_before]').val();
        data.html_content_after = $('textarea[name=html_content_after]').val();	 	 
  	    data.nameaction = $(".base-settings input[name=nameaction]").val();
        
        admin.ajaxRequest({
            mguniqueurl: "action/saveBaseOption", // действия для выполнения на сервере
            pluginHandler: 'payqr-settings', // плагин для обработки запроса
            data: data // id записи
          },
          function(response) {
            admin.indication(response.status, response.msg);
          }
        );
        
      });
    },
  }
})();

payqrActionModule.init();

$('select[name^=payqr_button_show_on_]').on('change', function(){
  
  var category_show_name = $(this).attr('name');

  var category_name = category_show_name.split("_")[category_show_name.split("_").length -1];

  if($(this).val() == "no")
  {
    $('[name^=payqr_'+category_name+'_button]').closest('tr').hide();
  }
  else
  {
    $('[name^=payqr_'+category_name+'_button]').closest('tr').show();
  }

});