<?php

class Pactioner extends Actioner {

  private $pluginName = 'payqr-settings';

  /**
   * Устанавливает количество отображаемых записей в разделе
   * @return boolean
   */
  public function saveBaseOption() {
    
    $this->messageSucces = $this->lang['SAVE_BASE'];
    $this->messageError = $this->lang['NOT_SAVE_BASE'];
    
    if (!empty($_POST['data'])) 
    {
      DB::query("UPDATE `".PREFIX."payment` SET paramArray = ".DB::quote(json_encode($_POST['data']))." WHERE name like '%PayQR%'");
    }
    
    return true;
  }
}