<?php

class mOrder{

	private $data_cart;

	private $user_data;

	private $cust_data;

	private $delivery;

	private $delivery_case_selected;

	private $config;

	
	public function __construct(&$Payqr, $config)
	{
		//получаем информацю о товарах
		$this->payqr_cart = $Payqr->objectOrder->getCart();

		//сохраняем информацию о пользователе
		$this->user_data = $Payqr->objectOrder->getUserData();

		//
		$this->cust_data = $Payqr->objectOrder->getCustomer();

		//
		$this->delivery = $Payqr->objectOrder->getDelivery();

		//
		$this->delivery_case_selected = $Payqr->objectOrder->getDeliveryCasesSelected();

		foreach($this->payqr_cart as $product_cart)
		{
			$this->data_cart[] = $product_cart;
		}

		$this->config = $config;
	}

	/**
	 * 
	 * @return int
	 */
	public function CreateOrder()
	{
		$order_id = 0;

		//формируем заказ
		$oData = $this->orderPrepareData();

		//производим вставку данных
		$order_id = $this->insertOrderData($oData);

		return $order_id;
	}

	/**
	 * 
	 * @return null|int
	 */
	public function getTotal()
	{
		$total = 0;

		//производим актуализацию корзины
		$cartData = new	CartData();

		if(!$cartData->actualizeCart($this->payqr_cart))
		{
			//не получилось актуализировать корзину
			return false;
		}

		//проверяем была ли выбрана доставка пользователем
		if(isset($this->delivery_case_selected, $this->delivery_case_selected->article) && !empty($this->delivery_case_selected->article))
		{
			$total = $cartData->getCartAmount($this->payqr_cart, $this->delivery_case_selected->article);
		}
		else
		{
			$total = $cartData->getCartAmount($this->payqr_cart, null);
		}
		
		return $total;
	}

	/**
	 * 
	 * @return null|int
	 */
	public function getClearTotal()
	{
		$total = 0;

		//производим актуализацию корзины
		$cartData = new	CartData();

		if(!$cartData->actualizeCart($this->payqr_cart))
		{
			//не получилось актуализировать корзину
			return false;
		}

		//проверяем была ли выбрана доставка пользователем
		$total = $cartData->getCartAmount($this->payqr_cart, null);
		
		return $total;
	}

	/**
	 * @param array $oData
	 * @return null|int
	 */
	private function insertOrderData($oData)
	{
		$query = 'INSERT INTO `mg_order` (`add_date`,`user_email`,`phone`,`address`,`summ`,`order_content`,`delivery_id`,`delivery_cost`,`payment_id`,`paided`,`status_id`,`comment`,`yur_info`,`name_buyer`,`ip`,`number`) 
						VALUES (
								'.DB::quote(date('Y-m-d h:i:s')).',
								'.DB::quote($oData['email']).',
								'.DB::quote(isset($oData['phone'])?$oData['phone']:'').',
								'.DB::quote($oData['address']).',
								'.DB::quote($oData['summ']).',
								'.DB::quote($oData['order_content']).',
								'.DB::quote($oData['delivery_id']).',
								'.DB::quote($oData['delivery_cost']).',
								'.DB::quote($oData['payment_id']).',
								'.DB::quote($oData['paided']).',
								'.DB::quote($oData['status_id']).',
								'.DB::quote($oData['comment']).',
								"",
								'.DB::quote($oData['name_bayer']).',
								'.DB::quote($oData['ip']).',
								'.DB::quote($oData['number']).')';

		DB::query($query);

		if($order_id = DB::insertId())
		{
			return $order_id;
		}
		return null;
	}

	/**
	 * @return array
	 */
	private function orderPrepareData()
	{
		$oData = array();

		if(isset($this->cust_data->email) && !empty($this->cust_data->email))
		{
			$oData['email'] = $this->cust_data->email;
		}

		if(isset($this->cust_data->firstName) && !empty($this->cust_data->firstName))
		{
			$oData['name_bayer'] = $this->cust_data->firstName;
		}

		if(isset($this->cust_data->lastName) && !empty($this->cust_data->lastName))
		{
			$oData['name_bayer'] .= " " . $this->cust_data->lastName;
		}

		if(isset($this->cust_data->middleName) && !empty($this->cust_data->middleName))
		{
			$oData['name_bayer'] .= " " . $this->cust_data->middleName;
		}

		if(isset($oData['name_bayer']) && empty($oData['name_bayer']))
		{
			$oData['name_bayer'] .= "Укажите запрос параметров пользователя в настройках PayQR";
		}

		if(isset($this->cust_data->phone) && !empty($this->cust_data->phone))
		{
			$oData['phone'] = $this->cust_data->phone;
		}
		
		//формиурем адрес доставки
		$oData['address'] = "";

		if(isset($this->delivery->country) && !empty($this->delivery->country))
		{
			$oData['address'] .= " ". $this->delivery->country;
		}

		if(isset($this->delivery->city) && !empty($this->delivery->city))
		{
			$oData['address'] .= ", ". $this->delivery->city;
		}

		if(isset($this->delivery->zip) && !empty($this->delivery->zip))
		{
			$oData['address'] .= ", ". $this->delivery->zip;
		}

		if(isset($this->delivery->street) && !empty($this->delivery->street))
		{
			$oData['address'] .= ", ". $this->delivery->street;
		}

		if(isset($this->delivery->house) && !empty($this->delivery->house))
		{
			$oData['address'] .= ", ". $this->delivery->house;
		}

		$oData['address'] = trim($oData['address']);

		if(empty($oData['address']))
		{
			$oData['address'] .= "Укажите запрос адреса доставки пользователя в настройках PayQR";
		}

		
		$oData['summ'] = $this->getClearTotal();


		//формиурем 
		$products = array();

		foreach($this->data_cart as $dc_product)
		{
			if(!isset($dc_product->article) && empty($dc_product->article))
			{
				continue;
			}

			$oProduct = new Product();

			$product = $oProduct->getProduct($dc_product->article);

			$products[] = 
				array(
					'id' => $product['id'],
					'name' => $product['title'],
					'url' => $oProduct->getProductImageUrl($dc_product->article),
					'code' => $product['code'],
					'price' => $product['price_course'],
					'count' => $dc_product->quantity,
					'property' => "",
					'coupon' => "", //????
					'discount' => 0,
					'info' => "",
					'fulPrice' => $product['price_course'],
					'weight' => $product['weight'],
					'currency_iso' => $product['currency_iso'],
					'discSyst' => '',
				);
		}


		if(!empty($products))
		{
			$oData['order_content'] = serialize($products);
		}

		if(isset($this->delivery_case_selected->article) && !empty($this->delivery_case_selected->article))
		{
			$oData['delivery_id'] = $this->delivery_case_selected->article;
		}
		else 
		{
			$oData['delivery_id'] = 3;//без доставки
		}

		if(isset($this->delivery_case_selected->amountTo) && !empty($this->delivery_case_selected->amountTo))
		{
			$oData['delivery_cost'] = $this->delivery_case_selected->amountTo;
		}
		else 
		{
			$oData['delivery_cost'] = 0;
		}

		$settings = Settings::initConfig($this->config);
                $payqr_settings = $settings->getSettings();

		$oData['payment_id'] = $settings->getPayQRId();

		$oData['paided'] = 0; // не оплатил

		$oData['status_id']	= $payqr_settings->payqr_status_creatted; //ожидает оплаты

		$oData['comment'] = "Заказ сделан через платежную систему PayQR";

		$oData['ip'] = $_SERVER['REMOTE_ADDR'];

		$oData['number'] = "";

		return $oData;
	}

	/**
	 * @param string  $message optional null
	 * @param integer $line optional 0
	 * @param bool    $debug optional false
	 * @param bool    $delete_old_log_file optional false
	 */
	private function __log($message = null, $line = 0, $debug = false, $delete_old_log_file = false)
	{
		if($delete_old_log_file)
		{
			@unlink("__worker.log");
		}

		if(empty($message) || !$debug)
		{
			return;
		}

		$fp = fopen("__worker.log", "a");

		fwrite($fp, "[" . $line . "]\r\n");

		fwrite($fp, "\t" . $message . "\r\n");

		fclose($fp);
	}
}