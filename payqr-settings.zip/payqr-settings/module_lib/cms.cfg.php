<?php

$config = [
	'settings' => [
		
		'table' => 'mg_payment',
		
		'view_type' => 'single_row', // ['single_row', 'multi_row']

		'view_store_type' => 'json', // ['serialize', 'json', 'simple']

		'plugin_name' => 'PayQR',
	]
];