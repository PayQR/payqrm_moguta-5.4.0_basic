<?php

class Delivery {

	/**
	 * @return array
	 */
	public static function getDeliveries()
	{
		$deliveries = array();

		$res = DB::query("SELECT id, name, cost, free, description FROM mg_delivery WHERE activity=1");

		while ($delivery = DB::fetchAssoc($res))
		{
			$deliveries[] = array(
				'id' => $delivery['id'],
				'name' => $delivery['name'],
				'cost' => $delivery['cost'],
				'free' => $delivery['free'],
				'description' => $delivery['description']
			);
		}

		return $deliveries;
	}

	/**
	 * @param int $delivery_id
	 * @return array
	 */
	public static function getDelivery($delivery_id = null)
	{
		if(is_null($delivery_id))
		{
			return null;
		}

		$res = DB::query("SELECT name, cost, free, description FROM mg_delivery WHERE id = " . DB::quote($delivery_id));

		return DB::fetchAssoc($res);
	}

	/**
	 * @param int $delivery_id
	 * @return array
	 */
	public static function getSysInfoDelivery($delivery_id = null)
	{
		$delivery = self::getDelivery($delivery_id);

		if(empty($delivery))
		{
			return array();
		}

		//формируем информацию о доставке для заказа
		$delivery = array(
			"person_type" => "natural",
		    "ip" => $_SERVER['REMOTE_ADDR'],
		    "driver" => "stub",
		    "fee_percent" => "0.00",
		    "fee_curr" => "",
		    "fee_const" => "0.00"
		);

		return $delivery;
	}

	/**
	 * @param int $delivery_id
	 * @param payqr_receiver $Payqr
	 * @return array
	 */
	public static function getCustInfoDelivery($delivery_id = null, $Payqr)
	{
		$delivery = self::getDelivery($delivery_id);

		if(empty($delivery))
		{
			return array();
		}

		//формируем информацию о доставке для заказа
		$delivery = array(
			'get_type_name' => $delivery['name'],
			'contact' => $contact
		);

		$user_delivery = $Payqr->objectOrder->getDelivery();

		if(!empty($user_delivery))
		{
			if(isset($user_delivery->street))
			{
				$delivery['street'] = $user_delivery->street;
			}
			if(isset($user_delivery->house))
			{
				$delivery['house'] = $user_delivery->house;
			}
			if(isset($user_delivery->building))
			{
				$delivery['building'] = $user_delivery->building;
			}
			if(isset($user_delivery->floor))
			{
				$delivery['floor'] = $user_delivery->floor;
			}
			if(isset($user_delivery->zip))
			{
				$delivery['code'] = $user_delivery->zip;
			}
			if(isset($user_delivery->unit))
			{
				$delivery['building'] = $user_delivery->unit;
			}
		}
		$delivery['app'] = '';
		$delivery['entrance'] = '';
		$delivery['delivery_date'] = '';
		$delivery['delivery_time'] = '';
		$delivery['station'] = '';
		$delivery['shipping_conflicts'] = 'show_intersection';


		return $delivery;
	}

	/**
	 * @param int $delivery_id
	 * 
	 */
	public static function calculateDeliveryAmount($delivery_id, $cart_amount)
	{
		$shipping_cost = 0;

		$delivery = self::getDelivery($delivery_id);

		if(empty($delivery))
		{
			return $shipping_cost;
		}

		$delivery = PayQRDelivery::getDelivery($delivery_id);

		if(!isset($delivery['type']) || !isset($delivery['amount']))
		{
			return $shipping_cost;
		}

		if($delivery['type'] == 'abs')
		{
			$shipping_cost = $delivery['amount'];
		}
		if($delivery['type'] == 'percent')
		{
			$shipping_cost = round($cart_amount * $delivery['amount'] / 100, 1);
		}

		return $shipping_cost;
	}

	/**
	 * @param string  $message optional null
	 * @param integer $line optional 0
	 * @param bool    $debug optional false
	 * @param bool    $delete_old_log_file optional false
	 */
	private static function __log($message = null, $line = 0, $debug = false, $delete_old_log_file = false)
	{
		if($delete_old_log_file)
		{
			@unlink("__worker.log");
		}

		if(empty($message) || !$debug)
		{
			return;
		}

		$fp = fopen("__worker.log", "a");

		fwrite($fp, "[" . $line . "]\r\n");

		fwrite($fp, "\t" . $message . "\r\n");

		fclose($fp);
	}
}