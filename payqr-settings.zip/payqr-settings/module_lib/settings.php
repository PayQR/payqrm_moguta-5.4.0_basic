<?php 

class Settings {

	protected static $_instance;

	protected $config;

	private $settings = array();


	private function __construct($config)
	{
		$this->config = $config;

		$this->_getSettings();
	}

	private function __clone(){}

	
	public static function initConfig($config) 
	{
		// проверяем актуальность экземпляра
		
		if (null === self::$_instance) 
		{
			// создаем новый экземпляр
			
			self::$_instance = new self($config);
		}
		
		// возвращаем созданный или существующий экземпляр
		
		return self::$_instance;
	}

	
	private function _getSettings()
	{
		$res = DB::query("SELECT paramArray FROM `". $this->config['settings']['table']."` WHERE name like '%". $this->config['settings']['plugin_name'] ."%'");

		if($this->config['settings']['view_type'] == 'single_row')
		{
			$payqr_settings = DB::fetchAssoc($res);

			switch($this->config['settings']['view_store_type'])
			{
				case 'serialize':
					$this->settings = unserialize($payqr_settings['paramArray']);
					break;
				case 'json':
					$this->settings = json_decode($payqr_settings['paramArray']);
					break;
				case 'simple':
					$this->settings = $payqr_settings['paramArray'];
					break;
				default:
					$this->settings = $payqr_settings['paramArray'];
					break;
			}
		}
		else 
		{
			while ($payqr_settings = DB::fetchAssoc($res))
			{
				$this->settings[] = $payqr_settings['paramArray'];
			}
		}

		return $this->settings;
	}

	public function getPayQRId()
	{
		$res = DB::query("SELECT id FROM `". $this->config['settings']['table']."` WHERE name like '%". $this->config['settings']['plugin_name'] ."%'");

		$payqr = DB::fetchAssoc($res);

		if(isset($payqr['id']) && !empty($payqr['id']))
		{
			return $payqr['id'];
		}

		return null;

	}

	
	public function getSettings()
	{
		return $this->_getSettings();
	}

	public function getPayQRSettings()
	{
		return array(
			"payqr_merchant_id" => "",
			"payqr_merchant_secret_key_in" => "",
			"payqr_merchant_secret_key_out" => "",
			"payqr_hook_handler_url" => 'http://' . $_SERVER['HTTP_HOST'] . '/' . 'payqr_receiver.php',
			"payqr_log_url" => 'http://' . $_SERVER['HTTP_HOST'] . '/' . 'payqr.log',
			"payqr_button_show_on_cart" => "yes",
			"payqr_cart_button_color" => "default",
			"payqr_cart_button_form" => "default",
			"payqr_cart_button_shadow" => "default",
			"payqr_cart_button_gradient" => "default",
			"payqr_cart_button_font_trans" => "default",
			"payqr_cart_button_font_width" => "default",
			"payqr_cart_button_text_case" => "default",
			"payqr_cart_button_height" => "auto",
			"payqr_cart_button_width" => "auto",
			"payqr_button_show_on_product" => "yes",
			"payqr_product_button_color" => "default",
			"payqr_product_button_form" => "default",
			"payqr_product_button_shadow" => "default",
			"payqr_product_button_gradient" => "default",
			"payqr_product_button_font_trans" => "default",
			"payqr_product_button_font_width" => "default",
			"payqr_product_button_text_case" => "default",
			"payqr_product_button_height" => "auto",
			"payqr_product_button_width" => "auto",
			"payqr_button_show_on_category" => "yes",
			"payqr_category_button_color" => "default",
			"payqr_category_button_form" => "default",
			"payqr_category_button_shadow" => "default",
			"payqr_category_button_gradient" => "default",
			"payqr_category_button_font_trans" => "default",
			"payqr_category_button_font_width" => "default",
			"payqr_category_button_text_case" => "default",
			"payqr_category_button_height" => "auto",
			"payqr_category_button_width" => "auto",
			"payqr_status_creatted" => 0,
			"payqr_status_paid" => 2,
			"payqr_status_cancelled" => 4,
			"payqr_status_completed" => 5,
			"payqr_require_firstname" => "deny",
			"payqr_require_lastname" => "deny",
			"payqr_require_middlename" => "deny",
			"payqr_require_phone" => "deny",
			"payqr_require_email" => "deny",
			"payqr_require_delivery" => "deny",
			"payqr_require_deliverycases" => "deny",
			"payqr_require_pickpoints" => "deny",
			"payqr_require_promo" => "deny",
			"payqr_promo_code" => "",
                    //
			"payqr_invordercreating_message_text" => "",
			"payqr_invordercreating_message_imageurl" => "",
			"payqr_invordercreating_message_url" => "",
                        
                        "payqr_invpaid_message_text" => "",
			"payqr_invpaid_message_imageurl" => "",
			"payqr_invpaid_message_url" => "",
                        
                        "payqr_invrevert_message_text" => "",
			"payqr_invrevert_message_imageurl" => "",
			"payqr_invrevert_message_url" => ""
		);
	}
}