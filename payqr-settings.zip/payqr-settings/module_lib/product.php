<?php

class Product{

	private $moguta_product;

	public function __construct()
	{
		$this->moguta_product = new Models_Product();
	}

	/**
	 * @param int $product_id
	 * @return array
	 */
	public function getProduct($product_id = null)
	{
		if(empty($product_id))
		{
			return array();
		}

		return $this->moguta_product->getProduct($product_id);
	}

	public function getProductImages($product_id)
	{
		$product = $this->getProduct($product_id);

		if(isset($product) && !empty($product['images_product']))
		{
			return $product['images_product'];
		}
		return array();
	}

	public function getProductImage($product_id)
	{
		$images = $this->getProductImages($product_id);

		if(isset($images[0]))
		{
			return $images[0];
		}
		return;
	}

	public function getProductImageUrl($product_id)
	{
		$pImg = $this->getProductImage($product_id);

		if(!empty($pImg) && file_exists( "uploads/" . $pImg))
		{
			return 'http://' . $_SERVER['HTTP_HOST'] . "/uploads/" . $pImg;
		}
		return null;
	}
}