<?php

$settings = Settings::initConfig($config);

$payqr_settings = $settings->getSettings();


if(isset($payqr_settings, $payqr_settings->payqr_status_cancelled))
{
	$order_id = $Payqr->objectOrder->getOrderId();
        
        if(empty($order_id))
        {
            return false;
        }
	
	DB::query("UPDATE `mg_order` SET status_id = ".DB::quote($payqr_settings->payqr_status_cancelled)." WHERE id = " . DB::quote($order_id));
}