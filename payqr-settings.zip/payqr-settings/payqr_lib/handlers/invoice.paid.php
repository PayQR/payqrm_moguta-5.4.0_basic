<?php

$settings = Settings::initConfig($config);
$payqr_settings = $settings->getSettings();

if(isset($payqr_settings, $payqr_settings->payqr_status_paid))
{
    if(isset($payqr_settings, $payqr_settings->payqr_invpaid_message_text, 
             $payqr_settings->payqr_invpaid_message_imageurl, 
             $payqr_settings->payqr_invpaid_message_url) && 
            (!empty($payqr_settings->payqr_invpaid_message_text) || 
             !empty($payqr_settings->payqr_invpaid_message_imageurl) || 
             !empty($payqr_settings->payqr_invpaid_message_url))
      )
    {
        $Payqr->objectOrder->data->message->article = 1;
        $Payqr->objectOrder->data->message->text = $payqr_settings->payqr_invpaid_message_text;
        $Payqr->objectOrder->data->message->imageUrl = $payqr_settings->payqr_invpaid_message_imageurl;
        $Payqr->objectOrder->data->message->url = $payqr_settings->payqr_invpaid_message_url;
    }

	$order_id = $Payqr->objectOrder->getOrderId();

	DB::query("UPDATE `mg_order` SET status_id = ".DB::quote($payqr_settings->payqr_status_paid)." WHERE id = " . DB::quote($order_id));
}