<?php

//получаем способы доставки товара
//получаем статусы заказов
//получаем информацию о кнопке
$settings = Settings::initConfig($config);
$payqr_settings = $settings->getSettings();

$delivery_cases = array();

if(isset($payqr_settings) && !empty($payqr_settings->payqr_require_deliverycases)
	&& $payqr_settings->payqr_require_deliverycases != "deny")
{
	$result = Delivery::getDeliveries();

	$i = 1;

	foreach($result as $delivery)
	{
		$amount = 0;

		if($delivery['free'] <= $Payqr->objectOrder->getAmount())
		{
			$delivery_cases[] = array(
				'article' => $delivery['id'],
				'number' => $i++,
				'name' => $delivery['name'],
				'description' => $delivery['description'],
				'amountFrom' => 0,
				'amountTo' => 0,
			);
		}
		else
		{
			$delivery_cases[] = array(
				'article' => $delivery['id'],
				'number' => $i++,
				'name' => $delivery['name'],
				'description' => $delivery['description'],
				'amountFrom' => $delivery['cost'],
				'amountTo' => $delivery['cost'],
			);
		}
	}
}

$Payqr->objectOrder->setDeliveryCases($delivery_cases);