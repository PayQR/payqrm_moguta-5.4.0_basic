<?php

if(isset($payqr_settings, $payqr_settings->payqr_invrevert_message_text, 
         $payqr_settings->payqr_invrevert_message_imageurl, 
         $payqr_settings->payqr_invrevert_message_url) && 
        (!empty($payqr_settings->payqr_invrevert_message_text) || 
         !empty($payqr_settings->payqr_invrevert_message_imageurl) || 
         !empty($payqr_settings->payqr_invrevert_message_url))
  )
{
    $Payqr->objectOrder->data->message->article = 1;
    $Payqr->objectOrder->data->message->text = $payqr_settings->payqr_invrevert_message_text;
    $Payqr->objectOrder->data->message->imageUrl = $payqr_settings->payqr_invrevert_message_imageurl;
    $Payqr->objectOrder->data->message->url = $payqr_settings->payqr_invrevert_message_url;
}