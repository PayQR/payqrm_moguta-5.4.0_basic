<?php

class ProductData extends ADataCart{

	private $amount;

	public function __construct()
	{
		$this->amount = 0;
	}

	/**
	 * @param int|null $param
	 * @return array
	 */
	public function initDataCart($param = null)
	{
		if(is_null($param))
		{
			return array();
		}

		$oProduct = new Product();
			
		$product = $oProduct->getProduct($param);

		if(empty($product)) 
		{
			return array();
		}

		$this->amount = $product['price'];

		$data_cart = array(
			"article" => $param,
			"name" =>  $product['title'],
			"imageUrl" => $oProduct->getProductImageUrl($param),
			"amount" => $product['price'],
			"quantity" => 1
		);

		return $data_cart;
	}

	/**
	 * 
	 * @return int;
	 */
	public function getAmount()
	{
		return $this->amount;
	}
}