<?php

class CartData extends ADataCart{

	private $amount;

	public function __construct()
	{
		$this->amount = 0;
	}

	/**
	 * @param int|null $param
	 * @return array
	 */
	public function initDataCart($param = null)
	{
		$product_cart = array();

		$modelcart = new Models_Cart();

		$itemsCart = $modelcart->getItemsCart();

		if(empty($itemsCart) || !isset($itemsCart['items']) || empty($itemsCart['items']))
		{
			return array();
		}

		foreach ($itemsCart['items'] as $item)
		{

			$oProduct = new Product();

			$product = $oProduct->getProduct($item['id']);

			$product_cart[] = array(
				"article" => $item['id'],
				"name" =>  $item['title'],
				"imageUrl" => $oProduct->getProductImageUrl($item['id']),
				"amount" => $item['price_course'] * $item['countInCart'],
				"quantity" => $item['countInCart']
			);

			$this->amount += $item['price_course'] * $item['countInCart'];

			unset($oProduct);
		}

		return $product_cart;
	}

	/**
	 * 
	 * @return int;
	 */
	public function getAmount()
	{
		return $this->amount;
	}

	/**
	* @param $payqr_cart
	* @return bool
	*/
	public function actualizeCart(&$payqr_cart)
	{
		foreach($payqr_cart as $payqr_product)
		{
			$oProduct = new Product();

			//получаем товар и его цену и модифицируем data-cart
			$item = $oProduct->getProduct($payqr_product->article);

			if(empty($item) || empty($item['id']))
			{
				return false;
			}

			$payqr_product->amount = $this->calcDiscount($item);
		}

		return true;
	}

	/**
	 * @param array $item
	 * @return float $price
	 */
	private function calcDiscount($item)
	{
		$price = 0;

		if(isset($item['price_course']) && !empty($item['price_course']))
		{
			$price = $item['price_course'];
		}

		return $price;
	}

	/**
	* @param array $payqr_cart
	* @param mixed $delivery_id
	* @return int
	*/
	public function getCartAmount($payqr_cart, $delivery_id = null)
	{
		$total = 0;

		foreach($payqr_cart as $cart_product)
		{
			$oProduct = new Product();

			$product = $oProduct->getProduct($cart_product->article);

			$total += $cart_product->quantity * $product['price_course'];
		}

		if(!is_null($delivery_id))
		{
			//получаем способ доставки
			$delivery = Delivery::getDelivery($delivery_id);

			if($delivery)
			{
				if(isset($delivery['free']) && !empty($delivery['free']) && $delivery['free'] > $total)
				{
					$total += $delivery['cost'];
				}
			}
		}

		return $total;
	}

	/**
	* @param string  $message optional null
	* @param integer $line optional 0
	* @param bool    $debug optional false
	* @param bool    $delete_old_log_file optional false
	*/
	public function __log($message = null, $line = 0, $debug = false, $delete_old_log_file = false)
	{
		if($delete_old_log_file)
		{
			@unlink("__worker.log");
		}

		if(empty($message) || !$debug)
		{
			return;
		}

		$fp = fopen("__worker.log", "a");

		fwrite($fp, "[" . $line . "]\r\n");

		fwrite($fp, "\t" . $message . "\r\n");

		fclose($fp);
	}
}