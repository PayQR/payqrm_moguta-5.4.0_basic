<?php

abstract class ADataCart {
	abstract public function initDataCart($param);
	abstract public function getAmount();
}