<?php

class DataCartFabric{

	public function __construct(){}

	static public function init($page)
	{
		switch($page)
		{
			case 'cart':
				return new CartData();
				break;
			case 'product':
				return new ProductData();
				break;
			case 'category':
				return new CategoryData();
				break;
			default:
				return stdClass;
				break;
		}
	}
}