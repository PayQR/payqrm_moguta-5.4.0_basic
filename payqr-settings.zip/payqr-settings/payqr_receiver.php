<?php

if(!defined('CORE_DIR'))
  define('CORE_DIR', 'mg-core/');

if(!defined('CORE_LIB'))
  define('CORE_LIB', CORE_DIR.'lib/');

if(!defined('DEBUG_SQL'))
define('DEBUG_SQL', 0);

$includePath = array(CORE_DIR,CORE_LIB);
set_include_path('.'.PATH_SEPARATOR.implode(PATH_SEPARATOR, $includePath));
function __autoload($className){
  $path = str_replace('_', '/', strtolower($className));
  return include_once $path.'.php';
}

MG::getConfigIni();

// Инициализация компонентов CMS.
DB::init();
Storage::init();
PM::init();
MG::init();
URL::init();
User::init();
Mailer::init();

if(isset($_POST['clear_cart']) && !empty($_POST['clear_cart']))
{
  unset($_SESSION['cart']);
}

/**
 * Скрипт принимает и обрабатывает уведомления от PayQR
 */
if (!defined('PAYQR_ROOT_CONFIG')) {
  define('PAYQR_ROOT_CONFIG', dirname(__FILE__) . '/mg-plugins/payqr-settings/payqr_lib/');
}

if (!defined('PAYQR_MODULE_ROOT')) {
  define('PAYQR_MODULE_ROOT', dirname(__FILE__) . '/mg-plugins/payqr-settings/module_lib/');
}

require_once PAYQR_MODULE_ROOT . 'cms.cfg.php';
require_once PAYQR_MODULE_ROOT . 'settings.php';
require_once PAYQR_MODULE_ROOT . 'muser.php';
require_once PAYQR_MODULE_ROOT . 'morder.php';
require_once PAYQR_MODULE_ROOT . 'product.php';
require_once PAYQR_MODULE_ROOT . 'delivery.php';
require_once PAYQR_ROOT_CONFIG . 'payqr_config.php';
require_once PAYQR_ROOT_CONFIG . 'classes/adatacart.php';
require_once PAYQR_ROOT_CONFIG . 'classes/cartdata.php';

//получаем информацию о кнопке
$settings = Settings::initConfig($config);
$payqr_settings = $settings->getSettings();

payqr_config::init($payqr_settings->payqr_merchant_id, $payqr_settings->payqr_merchant_secret_key_in, $payqr_settings->payqr_merchant_secret_key_out);
payqr_config::$logFile = "payqr.log";
payqr_config::$enabledLog = true;

payqr_logs::addEnter();

try{
  $Payqr = new payqr_receiver(); // создаем объект payqr_receiver
  $Payqr->receiving(); // получаем идентификатор счета на оплату в PayQR
  // проверяем тип уведомления от PayQR
  switch ($Payqr->getType()) {
    case 'invoice.deliverycases.updating':
      // нужно вернуть в PayQR список способов доставки для покупателя
      require_once PAYQR_HANDLER.'invoice.deliverycases.updating.php';
      break;
    case 'invoice.pickpoints.updating':
      // нужно вернуть в PayQR список пунктов самовывоза для покупателя
      require_once PAYQR_HANDLER.'invoice.pickpoints.updating.php';
      break;
    case 'invoice.order.creating':
      // нужно создать заказ в своей учетной системе, если заказ еще не был создан, и вернуть в PayQR полученный номер заказа (orderId), если его еще не было
      require_once PAYQR_HANDLER.'invoice.order.creating.php';
      break;
    case 'invoice.paid':
      // нужно зафиксировать успешную оплату конкретного заказа
      require_once PAYQR_HANDLER.'invoice.paid.php';
      break;
    case 'invoice.failed':
      // ошибка совершения покупки, операция дальше продолжаться не будет
      require_once PAYQR_HANDLER.'invoice.failed.php';
      break;
    case 'invoice.cancelled':
      // PayQR зафиксировал отмену конкретного заказа до его оплаты
      require_once PAYQR_HANDLER.'invoice.cancelled.php';
      break;
    case 'invoice.reverted':
      // PayQR зафиксировал полную отмену конкретного счета (заказа) и возврат всей суммы денежных средств по нему
      require_once PAYQR_HANDLER.'invoice.reverted.php';
      break;
    case 'revert.failed':
      // PayQR отказал интернет-сайту в отмене счета и возврате денежных средств покупателю
      require_once PAYQR_HANDLER.'revert.failed.php';
      break;
    case 'revert.succeeded':
      // PayQR зафиксировал отмену счета интернет-сайтом и вернул денежные средства покупателю
      require_once PAYQR_HANDLER.'revert.succeeded.php';
      break;
    default:
  }
  $Payqr->response();
}
catch (payqr_exeption $e){
  if(file_exists(PAYQR_ERROR_HANDLER.'invoice_action_error.php'))
  {
    $response = $e->response;
    require PAYQR_ERROR_HANDLER.'receiver_error.php';
  }
}

/**
* @param string  $message optional null
* @param integer $line optional 0
* @param bool    $debug optional false
* @param bool    $delete_old_log_file optional false
*/
function __log($message = null, $line = 0, $debug = false, $delete_old_log_file = false)
{
  if($delete_old_log_file)
  {
    @unlink("__worker.log");
  }

  if(empty($message) || !$debug)
  {
    return;
  }

  $fp = fopen("__worker.log", "a");

  fwrite($fp, "[" . $line . "]\r\n");

  fwrite($fp, "\t" . $message . "\r\n");

  fclose($fp);
}