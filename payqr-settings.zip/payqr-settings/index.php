<?php
/* 
  Plugin Name: Payqr 
  Plugin URI: http://payqr.ru 
  Description: Плагин для осуществления платежей через систему PayQR. 
  Author: PayQR Version: 1.0 
*/
include '/mg-core/models/cart.php';
include '/mg-core/models/product.php';
include 'module_lib/cms.cfg.php';
include 'module_lib/settings.php';
include 'module_lib/product.php';
include 'payqr_lib/classes/adatacart.php';
include 'payqr_lib/classes/button.php';
include 'payqr_lib/classes/datacartfabric.php';
include 'payqr_lib/classes/cartdata.php';
include 'payqr_lib/classes/categorydata.php';
include 'payqr_lib/classes/productdata.php';

new PayqrSettings($config);

class PayqrSettings {

	private static $lang = array(); // массив с переводом плагина 
	private static $pluginClass = '';
	private static $path = ''; //путь до файлов плагина 
	private static $config;

	public function __construct($config)
	{
		self::$pluginClass = PM::getFolderPlugin(__FILE__);
		self::$lang = PM::plugLocales(self::$pluginClass);
		self::$path = PLUGIN_DIR.self::$pluginClass;
		self::$config = $config;
		
		mgActivateThisPlugin(__FILE__, array(__CLASS__, 'activate'));
		mgAddAction(__FILE__, array(__CLASS__, 'pageSettingsPlugin'));

		// подключаем CSS плагина для всех страниц, кроме админки
		if (!URL::isSection('mg-admin')) 
		{
			$settingsObj = Settings::initConfig(self::$config);
			$settings = $settingsObj->getSettings();

			if(!empty($settings) && isset($settings->payqr_merchant_id))
      		{
      			mgAddMeta('<script src="https://payqr.ru/popup.js?merchId='.$settings->payqr_merchant_id.'"></script>');
      			mgAddMeta('<script src="'.SITE.'/'.self::$path.'/js/payqr_on_paid.js"></script>');
      		}
      		mgAddShortcode('init-button',  array(__CLASS__, 'initButton'));
    	}
	}

	/**
	* Метод выполняющийся при активации палагина 
	*/
	static public function activate()
	{
		$settingsObj = Settings::initConfig(self::$config); 

		DB::query("DELETE FROM `".PREFIX."payment` WHERE name like '%".self::$config['settings']['plugin_name']."%'");

		//проверка существования таблицы
		DB::query("INSERT INTO `".PREFIX."payment` (`name`, `activity`, `paramArray`, `urlArray`, `sort`) VALUES
			('".self::$config['settings']['plugin_name']."', '1', '".json_encode($settingsObj->getPayQRSettings())."', '', '1')");
	}

	/**
	* Выводит страницу настроек плагина в админке
	*/
	static public function pageSettingsPlugin()
	{
		$lang = self::$lang;

		$settingsObj = Settings::initConfig(self::$config);

		$entity = $settingsObj->getSettings();

		echo '<script type="text/javascript">includeJS("'.SITE.'/'.self::$path.'/js/script.js");</script>';

		include('pageplugin.php');
	}

	static public function initButton($arg)
	{
		$user_data = array();

		if(!isset($arg['page']))
		{
			return "";
		}
		
		//Получаем информацию по кнопке
		$settingsObj = Settings::initConfig(self::$config);
		
		$settings = $settingsObj->getSettings();

		
		//Добавляем информацию о пользователе в переменную arg[]
		$userData = User::getThis();

		if(isset($userData->email, $userData->id) && !empty($userData->email) && !empty($userData->id))
		{
			$user_data['email'] = $userData->email;
			$user_data['user_id'] = $userData->id;
		}


		//заносим информацию о кнопке в объект
		$bytton = new Button($arg['page'], $settings);

		$typeDataCartObj = DataCartFabric::init($arg['page']);

		if(method_exists($typeDataCartObj, 'initDataCart') && method_exists($typeDataCartObj, 'getAmount'))
		{
			$data_cart = $typeDataCartObj->initDataCart(  isset($arg['item_id']) ? $arg['item_id'] : null  );

			$data_cart_amount = $typeDataCartObj->getAmount();
			
			return $bytton->init("buy", $data_cart, $data_cart_amount, $user_data);
		}

		return "";
	}
}